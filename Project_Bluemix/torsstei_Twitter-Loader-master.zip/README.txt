Java Web Application

This sample application demonstrates how to use SQLDB service to connect DB2 on Bluemix.

Files

The Java Web starter application contains the following contents:

*   WebContent/

    This directory contains the client side code (HTML/CSS/JavaScript) of your application as well as compiled server side java classes and necessary JAR libraries.
    
*   src/

    This directory contains the server side code (JAVA) of your application.
    
*   build.xml

    This file allows you to easily build your application using Ant.
