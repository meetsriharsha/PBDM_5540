This project contains a ready to use application that allows you to query data from IBM Insights for Twitter service and load the results into a table in dashDB.

Push the following button to populate an own copy of the code in JazzHub and deploy the app under  your Bluemix account:

[![Deploy to Bluemix](https://bluemix.net/deploy/button.png)](https://bluemix.net/deploy?repository=https://hub.jazz.net/git/torsstei/Twitter-Loader)
